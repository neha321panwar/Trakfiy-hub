let taskData = {};

const todo = document.getElementById("todo");
const progressTask = document.getElementById("progress");
const done = document.getElementById("done");

let draggedItem = null;

const column111 = [todo, progressTask, done];

// Create Task
function createTask(title, desc, column) {
    const div = document.createElement("div");

    div.classList.add("task");
    div.setAttribute("draggable", "true");

    div.innerHTML = `
    <div class="task-title">
        <h2>${title}</h2>
        <p>${desc}</p>
        <button class="delete-btn">Delete</button>
    </div>
    `;

    column.appendChild(div);

    div.addEventListener("dragstart", () => {
        draggedItem = div;
    });

    // Delete Task
    div.querySelector(".delete-btn").addEventListener("click", () => {
        div.remove();
        updateTask();
    });

    return div;
}

// Update Local Storage + Count
function updateTask() {
    column111.forEach(col => {
        const tasks = col.querySelectorAll(".task");
        const count = col.querySelector(".right");

        taskData[col.id] = Array.from(tasks).map(task => ({
            title: task.querySelector("h2").innerText,
            taskArea: task.querySelector("p").innerText
        }));

        count.innerText = tasks.length;
    });

    localStorage.setItem("tasks", JSON.stringify(taskData));
}

// Load Tasks From Local Storage
if (localStorage.getItem("tasks")) {
    const data = JSON.parse(localStorage.getItem("tasks"));

    for (const col in data) {
        const column = document.getElementById(col);

        data[col].forEach(task => {
            createTask(task.title, task.taskArea, column);
        });
    }

    updateTask();
}

// Drag & Drop
function addDragEventsColumns(column) {
    column.addEventListener("dragenter", e => {
        e.preventDefault();
        column.classList.add("hover-over");
    });

    column.addEventListener("dragover", e => {
        e.preventDefault();
    });

    column.addEventListener("dragleave", () => {
        column.classList.remove("hover-over");
    });

    column.addEventListener("drop", e => {
        e.preventDefault();

        if (draggedItem) {
            column.appendChild(draggedItem);
            draggedItem = null;
        }

        column.classList.remove("hover-over");
        updateTask();
    });
}

addDragEventsColumns(todo);
addDragEventsColumns(progressTask);
addDragEventsColumns(done);

// Modal
const togglebtn = document.getElementById("togglr");
const modal = document.querySelector(".modal");
const bg = document.querySelector(".modal .bg");
const addBtn = document.getElementById("add-new-one");

togglebtn.addEventListener("click", () => {
    modal.classList.add("active");
});

bg.addEventListener("click", () => {
    modal.classList.remove("active");
});

// Add Task
addBtn.addEventListener("click", () => {
    const taskTitle = document.getElementById("tasktitleinput").value.trim();
    const taskArea = document.getElementById("task-textarea").value.trim();

    if (!taskTitle) {
        alert("Please enter task title");
        return;
    }

    createTask(taskTitle, taskArea, todo);

    updateTask();

    document.getElementById("tasktitleinput").value = "";
    document.getElementById("task-textarea").value = "";

    modal.classList.remove("active");
});